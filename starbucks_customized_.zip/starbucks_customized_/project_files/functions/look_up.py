import pymysql


def look_up_coffee():
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    query = "select * from starbucks_coffee"
    cursor.execute(query)
    data_origin = cursor.fetchall()
    data = [list(r) for r in data_origin]

    cursor.close()
    cnx.close()

    # data[0]: id, data[1]: name, data[2]: des, data[3]: origin price
    return data


def look_up_bread():
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    query = "select * from starbucks_bread"
    cursor.execute(query)
    data_origin = cursor.fetchall()
    data = [list(r) for r in data_origin]

    cursor.close()
    cnx.close()

    # data[0]: id, data[1]: name, data[2]: des, data[3]: origin price
    return data


def look_up_customized_coffee(current_id):
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    query = "select * from customized_coffee where customer_id_for_coffee='" + current_id + "'"
    cursor.execute(query)
    data_origin = cursor.fetchall()
    data = [list(r) for r in data_origin]
    """
        data[0]: customized_coffee_id
        data[1]: customer_id_for_coffee
        data[2]: coffee_id
        data[3]: size -> large, null 
        data[4]: cup -> take_out, eat_in
        data[5]: hot/cold -> hot, cold
        data[6]: coffee_add_shot -> yes, null
        data[7]: espresso_option -> yes, null
        data[8]: syrup -> yes, null
        data[9]: latte_add_milk -> yes, null
        data[10]: base -> yes, null
        data[11]: ice_option -> many, null
        data[12]: whip_cream -> yes, null
        data[13]: drizzle -> yes, null
        data[14]: cup_lid_option -> yes, null
        data[15]: price
    """

    cursor.close()
    cnx.close()

    return data


def look_up_customized_bread(current_id):
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    query = "select * from customized_bread where customer_id_for_bread='" + current_id + "'"
    cursor.execute(query)
    data_origin = cursor.fetchall()
    data = [list(r) for r in data_origin]

    """
    data[0]:customized bread id
    data[1]:customer id
    data[2]:bread id
    data[3]:lurpak butter
    data[4]:jam
    data[5]:cheese
    data[6]:add_price
    """
    cursor.close()
    cnx.close()

    return data


def look_up_order(current_id):
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()
    query = "select * from customized_order where customer_id_for_order='" + current_id + "'"
    cursor.execute(query)
    data_origin = cursor.fetchall()
    data = [list(r) for r in data_origin]

    cursor.close()
    cnx.close()

    return data
