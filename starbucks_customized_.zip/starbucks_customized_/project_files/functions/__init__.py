from functions import join_login as rl, look_up as lu, make_customized as mc, make_order as mo


# join
def join_init(_id, name, gen, p_n):
    res = rl.join(_id, name, gen, p_n)
    return res


# login
def login_init(input_id, input_pwd):
    res = rl.login(input_id, input_pwd)
    return res


# lookup_coffee
def look_up_coffee_init():
    data = lu.look_up_coffee()
    return data


# lookup_bread
def look_up_bread_init():
    data = lu.look_up_bread()
    return data


# lookup_customized_coffee
def look_up_customized_coffee_init(cur_id):
    data = lu.look_up_customized_coffee(cur_id)
    return data


# lookup_customized_bread
def look_up_customized_bread_init(cur_id):
    data = lu.look_up_customized_bread(cur_id)
    return data


# make customized bread
def make_customized_bread_init(cur_id, st_bread_id, butter, jam, cheese):
    res = mc.make_customized_bread(cur_id, st_bread_id, butter, jam, cheese)
    return res


# make customized coffee
def make_customized_coffee_init(current_id, st_coffee_id, size, cup, hot_cold, coffee_add_shot, espresso_option,
                                syrup, latte_add_milk, base, ice_option, whip_cream, drizzle, cup_lid_option):
    res = mc.make_customized_coffee(current_id, st_coffee_id, size, cup, hot_cold, coffee_add_shot, espresso_option,
                                    syrup, latte_add_milk, base, ice_option, whip_cream, drizzle, cup_lid_option)

    return res


# return new id
def new_order_id_init():
    res = mo.new_order_id()

    return res


# show shops
def shop_shops_init():
    data_shop = mo.show_shops()

    return data_shop


# show payments
def show_payments_init(c_id):
    data_pay = mo.show_payments(c_id)

    return data_pay


# calculate price
def calculate_price_init(c_id, c_b, pay_method, coupon):
    res = mo.calculate_price(c_id, c_b, pay_method, coupon)

    return res


# calculate price after discount
def calculate_discount_init(price, discount_code):
    final_price = mo.calculate_discount(price, discount_code)

    return final_price


# putting order
def put_order_init(c_id, shop_id, product_id, pay_method, pay_amount):
    mo.put_order(c_id, shop_id, product_id, pay_method, pay_amount)


# show orders
def look_up_order_init(current_id):
    data = lu.look_up_order(current_id)
    return data