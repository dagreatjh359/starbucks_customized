import pymysql


def new_order_id():
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    query = "select customized_order_id from customized_order"
    cursor.execute(query)

    raw_ids = cursor.fetchall()
    ids = [list(r) for r in raw_ids]
    last_id = max(ids)
    last_id = last_id[0]
    last_id = int(last_id)
    next_id = last_id + 1
    next_id = str(next_id)

    cursor.close()
    cnx.close()

    return next_id


def show_shops():
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    query = "select * from starbucks_shop"
    cursor.execute(query)
    raw_data = cursor.fetchall()
    data_shop = [list(r) for r in raw_data]

    cursor.close()
    cnx.close()

    return data_shop


def show_payments(c_id):
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    query = "select * from payment where customer_id_for_payment='"+c_id+"'"
    cursor.execute(query)
    raw_data = cursor.fetchall()
    data_pay = [list(r) for r in raw_data]

    cursor.close()
    cnx.close()

    return data_pay


def calculate_price(c_id, c_b, payment_method, coupon):
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    print(coupon)
    if coupon == 'No coupon' or coupon =='':
        if payment_method == 'coupon':
            return "this is wrong payment"
    if c_b == 1:
        table = 'customized_coffee'
        table_o = 'starbucks_coffee'
        customized_id = 'customized_coffee_id'
        original_id = 'coffee_id'
    else:
        table = 'customized_bread'
        table_o = 'starbucks_bread'
        customized_id = 'customized_bread_id'
        original_id = 'bread_id'

    query = "select additional_price, "+original_id+" from "+table+" where "+customized_id+"='"+c_id+"'"
    cursor.execute(query)
    raw_data = cursor.fetchone()
    add_price = raw_data[0]
    found_origin_id = raw_data[1]

    query = "select price from "+table_o+" where "+original_id+"='"+found_origin_id+"'"
    cursor.execute(query)
    raw_data = cursor.fetchone()
    origin_price = int(raw_data[0])

    total_price = add_price + origin_price

    if payment_method == 'coupon':
        total_price = add_price
    elif payment_method == 'credit_card':
        total_price = total_price * 0.9

    cursor.close()
    cnx.close()

    return total_price


def calculate_discount(price, discount_code):
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()
    query = "update payment set discount_code = 'null' where discount_code = '"+discount_code+"'"

    cursor.execute(query)

    cursor.close()
    cnx.close()

    if discount_code:
        price = price * 0.7

    return str(price)


def put_order(c_id, shop_id, product_id, pay_method, pay_amount):
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    query = "select customized_order_id from customized_order"
    cursor.execute(query)
    raw_ids = cursor.fetchall()
    ids = [list(r) for r in raw_ids]
    last_id = max(ids)
    last_id = last_id[0]
    last_id = int(last_id)
    next_id = last_id + 1
    next_id = str(next_id)
    print(next_id)
    print(type(pay_amount))
    pay_amount = float(pay_amount)
    pay_amount = int(pay_amount)
    pay_amount = str(pay_amount)

    print(product_id)
    if product_id[0] == '1' and product_id[1] == '0':
        query = "insert customized_order value('"+next_id+"', '"+c_id+"', '"+shop_id+"',null, '"+product_id+"',NOW(), 'KIM', '"+pay_method+"', "+pay_amount+")"
        print(query)
        cursor.execute(query)
    else:
        query = "insert customized_order value('" + next_id + "', '" + c_id + "', '" + shop_id + "', '" + product_id + "',null, NOW(), 'KIM', '" + pay_method + "'," + pay_amount + ")"
        print(query)
        cursor.execute(query)
