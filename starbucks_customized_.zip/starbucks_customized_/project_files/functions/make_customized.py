import pymysql


def make_customized_bread(current_id, st_bread_id, butter, jam, cheese):
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    add_price = 0
    options = [butter, jam, cheese]
    for ops in options:
        if ops == 'yes':
            add_price = add_price + 200

    add_price = str(add_price)

    query = "select customized_bread_id from customized_bread"
    cursor.execute(query)
    raw_ids = cursor.fetchall()
    ids = [list(r) for r in raw_ids]
    last_id = max(ids)
    last_id = last_id[0]
    last_id = int(last_id)
    next_id = last_id + 1
    next_id = str(next_id)

    query = "insert customized_bread value('"+next_id+"', '"+current_id+"', '"+st_bread_id+"', '"+butter+"', '"+jam+"', '"+cheese+"', '"+add_price+"')"
    cursor.execute(query)

    query = "select * from customized_bread where customized_bread_id = '"+next_id+"'"
    cursor.execute(query)

    res = cursor.fetchone()
    res = str(res)

    return res


def make_customized_coffee(current_id, st_coffee_id, size, cup, hot_cold, coffee_add_shot, espresso_option,
                           syrup, latte_add_milk, base, ice_option, whip_cream, drizzle, cup_lid_option):
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    """
        data[0]: customized_coffee_id
        data[1]: customer_id_for_coffee
        data[2]: coffee_id
        data[3]: size -> large, null 
        data[4]: cup -> take_out, eat_in
        data[5]: hot/cold -> hot, cold
        data[6]: coffee_add_shot -> yes, null
        data[7]: espresso_option -> yes, null
        data[8]: syrup -> yes, null
        data[9]: latte_add_milk -> yes, null
        data[10]: base -> yes, null
        data[11]: ice_option -> many, null
        data[12]: whip_cream -> yes, null
        data[13]: drizzle -> yes, null
        data[14]: cup_lid_option -> yes, null
        data[15]: price
    """

    add_price = 0
    options = [size, coffee_add_shot, espresso_option, syrup, latte_add_milk, base, ice_option, whip_cream, drizzle]
    for ops in options:
        if ops == 'large' or ops == 'yes' or ops == 'many':
            add_price = add_price + 200

    add_price = str(add_price)

    query = "select customized_coffee_id from customized_coffee"
    cursor.execute(query)
    raw_ids = cursor.fetchall()
    ids = [list(r) for r in raw_ids]
    last_id = max(ids)
    last_id = last_id[0]
    last_id = int(last_id)
    next_id = last_id + 1
    next_id = str(next_id)

    query = "insert customized_coffee value('"+next_id+"', '"+current_id+"', '"+st_coffee_id+"', '"+size+"', '"+cup+"', '"+hot_cold+"', '"+coffee_add_shot+"', '"+espresso_option+"', '"+syrup+"', '"+latte_add_milk+"', '"+base+"', '"+ice_option+"', '"+whip_cream+"', '"+drizzle+"', '"+cup_lid_option+"', '"+add_price+"')"
    cursor.execute(query)

    query = "select * from customized_coffee where customized_coffee_id = '" + next_id + "'"
    cursor.execute(query)

    res = cursor.fetchone()
    res = str(res)

    return res
