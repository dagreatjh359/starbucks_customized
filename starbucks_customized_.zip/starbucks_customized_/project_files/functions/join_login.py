import pymysql


def join(new_id, name, gender, phone_num):
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    try:
        new_id = str(new_id)
        name = str(name)
        gender = str(gender)
        phone_num = str(phone_num)

        query = "insert customer value('" + new_id + "','" + name + "','y','" + gender + "','" + phone_num + "')"
        cursor.execute(query)
        print("registered as " + new_id + ", " + name)
        response = "registered as " + new_id + ", " + name

    except pymysql.err.IntegrityError as e:
        print("this id is used or you are already registered")
        response = "this id is used or you are already registered"

    cursor.close()
    cnx.close()
    return response


def login(input_id, input_pwd):
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()

    try:
        input_id = str(input_id)

        query = "SELECT EXISTS(SELECT customer_id from customer where customer_id = '" + input_id + "' and " \
                                                                                                    "phone_number " \
                                                                                                    "='"+input_pwd+"') AS SUCCESS; "
        cursor.execute(query)

        data = cursor.fetchone()  # 1차원배열

        if data[0] == 1:
            response = "Logged in as " + input_id
        else:
            response = "Cannot find the id " + input_id

    except (pymysql.err.IntegrityError, ValueError):
        response = "Error has occurred"

    cursor.close()
    cnx.close()

    return response

