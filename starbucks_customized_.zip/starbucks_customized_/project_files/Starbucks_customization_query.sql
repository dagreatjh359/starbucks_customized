create database starbucks_customized;
use starbucks_customized;

-- ------------------------------------------------
-- customer_id = 2020_ _ _ _ _ _
-- customized_coffee_id = 10 _ _ _ _
-- customized_bread_id = 20 _ _ _ _
-- Coffee_id = 01 _ _
-- Bread_id = 02 _ _

-- cup : eat-in or take out
-- whip cream : less / normal / more
-- lid : yes or null

-- coupon_id_coffee = 11 _ _
-- coupon_id bread = 22_ _
-- discount_code = 33 _ _
-- credit_card_number = 16digit
-- user_radius_in = y or n
-- shop_id = 4040 _ _ _ _
-- customized_order_id = 5050_ _ _ _

-- 기존이랑 달라진 것들 : user_radius 추가, coupon_id_coffee/bread로 구분, ID varchar로 바꾼다.


CREATE TABLE IF NOT EXISTS starbucks_customized.Customer (
  customer_id VARCHAR(45) NOT NULL,
  name VARCHAR(45) NULL,
  is_a_member VARCHAR(45) NULL,
  gender VARCHAR(45) NULL,
  phone_number varchar(45) NULL,
  PRIMARY KEY (customer_id));
select * from customer;
insert customer value('2020112139', '유종현', 'y', 'm', '01038063152');
insert customer value('2020112148', '윤덕우', 'y', 'm', '01066138345');
insert customer value('2020112000', '임형식', 'n', 'f', '01011112222');
select EXISTS (select customer_id from customer where customer_id = '2020112139' limit 1) as success;

CREATE TABLE IF NOT EXISTS Starbucks_Coffee (
  Coffee_id VARCHAR(45) NOT NULL,
  product_name VARCHAR(45) NULL,
  coffeeDes VARCHAR(100) NULL,
  price INT NULL,
  PRIMARY KEY (Coffee_id));
  select * from starbucks_coffee;
  insert starbucks_coffee value('0100','americano','Coffee with the softest and coolest taste of Starbucks\' clean and intense espresso', 4500);
  insert starbucks_coffee value('0101','latte','Coffee with rich and rich espresso softened by fresh steam milk',5000);
  insert starbucks_coffee value('0102','grapefruit_honey_black_tea','Combination of teavana with sweet and sour grapefruit and sweet honey',5700);
  insert starbucks_coffee value('0103','java_chip_frappuccino','Frappuccino that you can feel coffee, mocha sauce, and rich chocolate chips',6300);
  
  CREATE TABLE IF NOT EXISTS starbucks_customized.Starbucks_Bread (
  Bread_id VARCHAR(45) NOT NULL,
  product_name VARCHAR(45) NULL,
  breadDes VARCHAR(100) NULL,
  price INT NULL,
  PRIMARY KEY (Bread_id));
select * from starbucks_bread;
insert starbucks_bread value('0200', 'peanut_sand', 'Rich nutty peanut cream between two soft bread sand.', 5300);
insert starbucks_bread value('0201', 'tiramishu', 'Coffee flavoured Italian Desert.', 5500);
insert starbucks_bread value('0202', 'sausage_pie', 'Pie with beefy sausage and soft bread.', 5500);    
  
    
CREATE TABLE IF NOT EXISTS starbucks_customized.Customized_bread (
  customized_bread_id VARCHAR(45) NOT NULL,
  customer_id_for_bread VARCHAR(45) NOT NULL,
  Bread_id VARCHAR(45) NULL,
  Lurpak_butter VARCHAR(45) NULL,
  Berry_Jam VARCHAR(45) NULL,
  Cream_Cheese VARCHAR(45) NULL,
  additional_price INT NULL,
  PRIMARY KEY (customized_bread_id, customer_id_for_bread),
  INDEX Bread_id_idx (Bread_id ASC) VISIBLE,
  INDEX customized_bread_id (customized_bread_id ASC) VISIBLE,
  CONSTRAINT Bread_id
    FOREIGN KEY (Bread_id)
   REFERENCES starbucks_customized.Starbucks_Bread (Bread_id)
   ON DELETE NO ACTION
   ON UPDATE NO ACTION,
  CONSTRAINT customer_id_for_bread
    FOREIGN KEY (customer_id_for_bread)
    REFERENCES starbucks_customized.Customer (customer_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
select * from customized_bread;
insert customized_bread value('200000', '2020112139', '0200', 'yes', 'yes','yes', 600);
insert customized_bread value('200001', '2020112139', '0201', 'no', 'no','no', 0);
insert customized_bread value('200002', '2020112148', '0200', 'yes', 'no','no', 200);
insert customized_bread value('200003', '2020112148', '0201', 'no', 'no','no', 0);
insert customized_bread value('200004', '2020112148','0202','yes','no','no',200);
insert customized_bread value('200005', '2020112000','0202','no','no','no',0);
insert customized_bread value('200006', '2020112139', '0200', 'yes', 'yes','yes', 600);

CREATE TABLE IF NOT EXISTS starbucks_customized.Customized_coffee (
  customized_coffee_id VARCHAR(45) NOT NULL,
  customer_id_for_coffee VARCHAR(45) NOT NULL,
  Coffee_id VARCHAR(45) NULL,
  size VARCHAR(45) NULL,
  cup VARCHAR(45) NULL,
  hot_cold VARCHAR(45) NULL,
  coffee_add_shot VARCHAR(45) NULL,
  espresso_option VARCHAR(45) NULL,
  syrup VARCHAR(45) NULL,
  latte_add_milk VARCHAR(45) NULL,
  base VARCHAR(45) NULL,
  ice_option VARCHAR(45) NULL,
  whip_cream VARCHAR(45) NULL,
  drizzle VARCHAR(45) NULL,
  cup_lid_option VARCHAR(45) NULL,
  price INT NULL,
  PRIMARY KEY (customized_coffee_id, customer_id_for_coffee),
  INDEX Coffee_id_idx (Coffee_id ASC) VISIBLE,
  CONSTRAINT customer_id_for_coffee
    FOREIGN KEY (customer_id_for_coffee)
    REFERENCES starbucks_customized.Customer (customer_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT Coffee_id
    FOREIGN KEY (Coffee_id)
    REFERENCES starbucks_customized.Starbucks_Coffee (Coffee_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
select * from customized_coffee;
alter table customized_coffee change price additional_price int;
insert customized_coffee value('100000','2020112148','0100','large','take_out','cold',Null,Null,Null,Null,Null,'many',Null,Null,Null,400); -- large, ice 'many'
insert customized_coffee value('100001','2020112139','0101',Null,'take_out','hot',Null,Null,Null,Null,Null,Null,Null,Null,Null,0); -- none
insert customized_coffee value('100002','2020112000','0102','large','eat_in','cold','yes',Null,'yes',Null,Null,'many',Null,Null,Null,800); -- large, add shot 'yes', syrup 'yes', ice 'many'
-- update customized_coffee set price = 400 where price = 200;
--    SET SQL_SAFE_UPDATES = 0;

-- payment_id 집어넣음
CREATE TABLE IF NOT EXISTS starbucks_customized.Payment(
  payment_id int not null,
  customer_id_for_payment VARCHAR(45) NOT NULL,
  payment_method VARCHAR(45) NOT NULL, -- coupon, credit_card 16digit, starbucks_card 8digit
  coupon_id_coffee VARCHAR(45) NULL, -- 11_ _
  coupon_id_bread VARCHAR(45) NULL, -- 22_ _
  starbucks_card_number VARCHAR(45) NULL,
  credit_card_number VARCHAR(45) NULL,
  discount_code VARCHAR(45) NULL, -- 33_ _
  PRIMARY KEY (payment_id, customer_id_for_payment, payment_method),
  INDEX payment_method (payment_method ASC) VISIBLE,
  CONSTRAINT customer_id_for_payment
    FOREIGN KEY (customer_id_for_payment)
    REFERENCES starbucks_customized.Customer (customer_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
select * from payment;
drop table payment;
insert payment value (1,'2020112139', 'coupon', null, '2200',null,null,null);
insert payment value (2,'2020112139', 'credit_card', null, null, null,'1111 2222 3333 4444', '3300');
insert payment value (3,'2020112148', 'coupon', '1100', null, null, null, null);
insert payment value (4,'2020112148', 'coupon', null, '2201', null, null, null);
insert payment value (5,'2020112148', 'credit_card', null,null,null, '1111 2222 3333 4445', '3301');
insert payment value (6,'2020112000', 'starbucks_card', null, null, '1111 2222', null, '3302');

    
CREATE TABLE IF NOT EXISTS starbucks_customized.Starbucks_shop (
  shop_id VARCHAR(45) NOT NULL,
  shop_address VARCHAR(45) NULL,
  DriveThrough_or_not VARCHAR(45) NULL,
  user_radius_in VARCHAR(45) NULL,
  PRIMARY KEY (shop_id));
  select * from starbucks_shop;
  insert starbucks_shop value('40400001', 'Seoul Junggu', 'yes', null);
  insert starbucks_shop value('40400002', 'Seoul Yangcheon', 'yes', null);
  insert starbucks_shop value('40400003', 'Seoul Jongno', 'no', null);
  insert starbucks_shop value('40400004', 'Gyeongido Euijeongbu', 'no', null);
  insert starbucks_shop value('40400005', 'Gyeonggido Yangju', 'yes', null);
  insert starbucks_shop value('40400006', 'Gyeonggido Gwangmyeong', 'no', null);
  update starbucks_shop set shop_address = 'Gyeonggido Euijeongbu' where shop_id = '40400004';



drop table customized_order;
CREATE TABLE IF NOT EXISTS starbucks_customized.Customized_Order (
  customized_order_id VARCHAR(45) NOT NULL,
  customer_id_for_order VARCHAR(45) NULL,
  shop_id VARCHAR(10) NULL,
  customized_bread_id VARCHAR(45) NULL,
  customized_coffee_id VARCHAR(45) NULL,
  created_date_time TIMESTAMP NULL,
  product_maker VARCHAR(45) NULL,
  payment_method VARCHAR(45) NULL,
  payment_amount INT NULL,
  PRIMARY KEY (customized_order_id),
  INDEX shop_id_idx (shop_id ASC) VISIBLE,
  INDEX customized_coffee_id_idx (customized_coffee_id ASC) VISIBLE,
  INDEX payment_method_idx (payment_method ASC) VISIBLE,
  INDEX customer_id_for_order_idx (customer_id_for_order ASC) VISIBLE,
  INDEX customized_bread_id_idx (customized_bread_id ASC) VISIBLE,
  CONSTRAINT customer_id_for_order
    FOREIGN KEY (customer_id_for_order)
    REFERENCES starbucks_customized.Payment (customer_id_for_payment)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT shop_id
    FOREIGN KEY (shop_id)
    REFERENCES starbucks_customized.Starbucks_shop (shop_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
CONSTRAINT customized_coffee_id
    FOREIGN KEY (customized_coffee_id)
    REFERENCES starbucks_customized.customized_coffee (customized_coffee_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
CONSTRAINT customized_bread_id
    FOREIGN KEY (customized_bread_id)
    REFERENCES starbucks_customized.customized_bread (customized_bread_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
 CONSTRAINT payment_method
    FOREIGN KEY (payment_method)
    REFERENCES starbucks_customized.Payment (payment_method)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
select * from customized_order;
update customized_order set payment_amount= 5000 where order_id = 2;
insert customized_order value ('50500000','2020112139', '40400001', '200000', null, null, 'KIM', 'credit_card', 11300);
insert customized_order value ('50500001','2020112139', '40400001', null, '100001', null, 'KIM', 'credit_card', 5000);
insert customized_order value ('50500002','2020112148', '40400003', '200002', null, null, 'BELL', 'coupon', 5500);
insert customized_order value ('50500003','2020112148', '40400003', null, '100000', null, 'BELL', 'coupon', 4900);
ALTER TABLE customized_order MODIFY COLUMN customized_order_id VARCHAR(45) PRIMARY KEY;
alter table customized_order drop primary key;
drop table customized_order;

select shop_id, shop_address
From starbucks_shop
Where shop_address like "%Gyeonggido%" and
		shop_id in( select shop_id
				From starbucks_shop
				Where DriveThrough_or_not = "no");