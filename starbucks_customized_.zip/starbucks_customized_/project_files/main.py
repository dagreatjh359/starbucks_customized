from flask import Flask, render_template, session, url_for, request, redirect
import functions as fnc
import pymysql

app = Flask(__name__)


@app.route('/')
def home():
    """
    res = fnc.show()
    print(res)
    """
    return render_template('DB_home.html')


@app.route('/logged_in_id=<logged_in_id>')
def home_logged_in(logged_in_id):
    return render_template('DB_home_2.html', c_id=logged_in_id)


@app.route('/join')
def view_join():
    return render_template('DB_join.html')


@app.route('/join_response', methods=['GET', 'POST'])
def view_join_res():
    if request.method == 'POST':
        new_id = request.form['id']
        new_name = request.form['name']
        new_phonenum = request.form['phonenumber']
        ## new_phonenum_again = request.form['phonenumber_Check']
        new_gender = request.form['gender']

        res = fnc.join_init(new_id, new_name, new_gender, new_phonenum)

        return render_template('DB_join_confirm.html', alert=res)


@app.route('/login')
def view_login():
    return render_template('DB_login.html')


@app.route('/login_response', methods=['POST'])
def view_login_res():
    input_id = request.form['c_id']
    input_pwd = request.form['Phone number']

    res = fnc.login_init(input_id, input_pwd)

    if res == "Logged in as " + input_id:
        session['username'] = input_id
        return render_template('DB_login_confirm.html', alert=res, logged_in_id=input_id)
    else:
        return render_template('DB_login_error.html', alert=res)


@app.route('/logout')
def logout():
    out = session.pop('username', None)
    res = out + " Logged out"
    return render_template('DB_logout_confirm.html', alert=res)


@app.route('/starbucks_coffee', methods=['GET'])
def view_coffee():
    data_c = fnc.look_up_coffee_init()
    c_id = session['username']

    return render_template('DB_coffee_order.html', origincoffee=data_c)


@app.route('/starbucks_bread', methods=['GET'])
def view_bread():
    data_b = fnc.look_up_bread_init()
    c_id = session['username']

    return render_template('DB_bread_order.html', originbread=data_b)


@app.route('/my_page', methods=['GET'])
def view_my_page():
    cur_id = session['username']
    cnx = pymysql.connect(user='root', password='YooJH@0319', host='localhost',
                          database='starbucks_customized', autocommit=True)
    cursor = cnx.cursor()
    query = "select name from customer where customer_id='" + cur_id + "'"
    cursor.execute(query)
    raw = cursor.fetchone()
    name = str(raw[0])

    cursor.close()
    cnx.close()

    data_c = fnc.look_up_customized_coffee_init(cur_id)
    data_b = fnc.look_up_customized_bread_init(cur_id)
    data_o = fnc.look_up_order_init(cur_id)

    return render_template('DB_mypage.html', data_b=data_b, data_c=data_c, data_o=data_o, c_id=cur_id, name=name)


@app.route('/make_order_coffee', methods=['POST'])
def view_make_order_coffee():
    c_coffee = request.form['c_coffee_id']
    new_order_id = fnc.new_order_id_init()
    print(new_order_id)
    c_id = session['username']
    data_shop = fnc.shop_shops_init()
    print(data_shop)  # id, address, drive through
    data_pay = fnc.show_payments_init(c_id)
    print(data_pay)

    credit_card = []
    starbucks_card = []
    coupon_coffee = []
    coupon_bread = ['Cannot_use']
    discount = []
    for r in data_pay:
        if r[2] == 'credit_card':
            credit_card.append(r)
        elif r[2] == 'coupon':
            if r[3]:
                coupon_coffee.append(r[3])
        elif r[2] == 'starbucks_card':
            starbucks_card.append(r)
        elif r[7]:
            discount.append(r[7])

    return render_template('DB_payment.html', c_product_id=c_coffee, order_id=new_order_id, c_id=c_id, shops=data_shop,
                           credit_card=credit_card, starbucks_card=starbucks_card, coupon_coffee=coupon_coffee,
                           coupon_bread=coupon_bread, discount=discount)


@app.route('/make_order_bread', methods=['POST'])
def view_make_order_bread():
    c_bread = request.form['c_bread_id']
    new_order_id = fnc.new_order_id_init()
    print(new_order_id)
    c_id = session['username']
    data_shop = fnc.shop_shops_init()
    print(data_shop)  # id, address, drive through
    data_pay = fnc.show_payments_init(c_id)
    print(data_pay)

    credit_card = []
    starbucks_card = []
    coupon_coffee = ['Cannot_use']
    coupon_bread = []
    discount = []
    for r in data_pay:
        if r[2] == 'credit_card':
            credit_card.append(r)
        elif r[2] == 'coupon':
            if r[4]:
                coupon_bread.append(r[4])
        elif r[2] == 'starbucks_card':
            starbucks_card.append(r)
        elif r[7]:
            discount.append(r[7])

    return render_template('DB_payment.html', c_product_id=c_bread, order_id=new_order_id, c_id=c_id, shops=data_shop,
                           credit_card=credit_card, starbucks_card=starbucks_card, coupon_coffee=coupon_coffee,
                           coupon_bread=coupon_bread, discount=discount)


@app.route('/payment_confirm=<c_product_id>', methods=['POST'])
def view_payment_confirm(c_product_id):
    product_id = c_product_id
    c_id = session['username']
    pay_method = request.form['payment_method']
    shop_id = request.form['shop_id']
    coupon_id_coffee = request.form['coupon_id_coffee']
    coupon_id_bread = request.form['coupon_id_bread']
    starbucks_card_no = request.form['starbucks_card_no']
    credit_card_no = request.form['credit_card_no']
    dis_code = request.form['dis_code']

    print(coupon_id_coffee)
    if product_id[0] == '1' and product_id[1] == '0':
        customized_coffee_id = product_id
        res = fnc.calculate_price_init(customized_coffee_id, 1, pay_method, coupon_id_coffee)
        if res == "this is wrong payment":
            c_id = session['username']
            return render_template('DB_order_error.html', alert=res, logged_in_id=c_id)
    else:
        customized_bread_id = product_id
        res = fnc.calculate_price_init(customized_bread_id, 2, pay_method, coupon_id_bread)
        if res == "this is wrong payment":
            c_id = session['username']
            return render_template('DB_order_error.html', alert=res, logged_in_id=c_id)

    final_price = fnc.calculate_discount_init(res, dis_code)

    fnc.put_order_init(c_id, shop_id, product_id, pay_method, final_price)

    return render_template('DB_order_confirm.html', alert=final_price)


@app.route('/save_customized_bread', methods=['POST'])
def customizing_bread():
    origin_bread_id = request.form['bread_id']
    butter = request.form['Lurpak_Butter']
    jam = request.form['Berry_Jam']
    cheese = request.form['Cream_Cheese']
    c_id = session['username']
    fnc.make_customized_bread_init(c_id, origin_bread_id, butter, jam, cheese)

    res = "Customized bread saved"

    return render_template('DB_custom_confirm.html', alert=res)


@app.route('/save_customized_coffee', methods=['POST'])
def customizing_coffee():
    origin_coffee_id = request.form['coffee_id']
    size = request.form['size']
    cup = request.form['cup']
    hot_cold = request.form['hot_cold']
    coffee_add_shot = request.form['coffee_add_shot']
    espresso_option = request.form['espresso_option']
    syrup = request.form['syrup']
    latte_add_milk = request.form['latte_add_milk']
    base = request.form['base']
    ice_option = request.form['ice_option']
    whip_cream = request.form['whip_cream']
    drizzle = request.form['drizzle']
    cup_lid_option = request.form['cup_lid_option']

    current_id = session['username']
    fnc.make_customized_coffee_init(current_id, origin_coffee_id, size, cup, hot_cold, coffee_add_shot, espresso_option,
                                    syrup, latte_add_milk, base, ice_option, whip_cream, drizzle, cup_lid_option)
    res = "Customized coffee saved"

    return render_template('DB_custom_confirm.html', alert=res)


@app.route('/tmp')
def tmp():
    a = request.form['bread_id']
    return a


if __name__ == '__main__':
    app.secret_key = 'super secret key'
    app.config['SESSION_TYPE'] = 'filesystem'
    app.run(debug=True)
