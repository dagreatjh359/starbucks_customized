# starbucks_customized
데베 프로젝트

pip install pymysql을 할 것
